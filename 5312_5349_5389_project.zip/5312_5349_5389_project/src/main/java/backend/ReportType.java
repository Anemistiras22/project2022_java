package backend;

public enum ReportType {
	TEXT, MD, HTML
}
