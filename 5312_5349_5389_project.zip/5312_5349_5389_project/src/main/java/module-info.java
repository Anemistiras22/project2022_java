/**
 * 
 */
/**
 * @author Deadicated
 *
 */
module eggs {
	requires java.desktop;
	requires junit;
}