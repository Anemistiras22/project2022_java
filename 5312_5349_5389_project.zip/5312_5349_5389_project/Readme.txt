Θ Α Ν Α Σ Η Σ   Ν Τ Ε Κ Ο Σ , Α Μ : 5 3 1 2
Α Λ Ε Ξ Α Ν Δ Ρ Ο Σ   Σ Ι Ο Υ Λ Α Σ , Α Μ : 5 3 4 9
Κ Ω Ν Σ Τ Α Ν Τ Ι Ν Ο Σ   Χ Α Τ Ζ Η Ι Ω Α Ν Ν Ο Υ , Α Μ : 5 3 8 9

Input files are at: ...\5312_5349_5389_project\src\main\resources\input

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.File;
import java.io.FileReader;